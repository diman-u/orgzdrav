<div class="offcanvas__panel" data-panel="user">
    <button type="button" class="btn-close js-panel-toggle" data-panel="user" aria-hidden="true">
        <span class="icon icon--md-x"></span>
    </button>
    <div id="orgzdrav-profile"></div>
</div>